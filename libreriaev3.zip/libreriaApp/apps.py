from django.apps import AppConfig


class LibreriaappConfig(AppConfig):
    name = 'libreriaApp'
