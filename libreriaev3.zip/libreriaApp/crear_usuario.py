
# que no se olvide antes de todo ejecutar el python manage.py shell

#from django.contrib.auth.models import User, Group

# Crear un usuario normal
#usuario = User.objects.create_user('rony', 'rony@ejemplo.com', 'rony1')

# Obtener o crear un grupo
#grupo_sin_privilegios, created = Group.objects.get_or_create(name='SinPrivilegios')

# Agregar el usuario al grupo
#usuario.groups.add(grupo_sin_privilegios)